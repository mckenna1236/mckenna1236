# By Sphinx H4CKNET
# InsTFollow
Best Tool For Increase Instagram Follower.

## Requirements
1. openssl
2. curl

## How to Install in Termux

`$ pkg up -y`

`$ pkg install openssl-tool`

`$ pkg install curl`

`$ pkg install git`

`$ cd insfollow`

`$ chmod +x insfollow.sh`

`$ termux-wake-lock`

`$ bash insfollow.sh´

